package tom.lk_architect_singleton_java.simple01;

/**
 * Created by tom on 2018/3/18.
 */

//标准单例模式(线程安全)
public class Singleton03 {

    public enum Static{

        instance(new Singleton03());

        private Singleton03 singleton;

        private  Static(Singleton03 singleton){
            this.singleton = singleton;
        }

        public Singleton03 getSingleton(){
            return  this.singleton;
        }
    }

    //构造方法私有化
    private Singleton03(){

    }

}

