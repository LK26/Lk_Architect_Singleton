package tom.lk_architect_singleton_java.simple01;

/**
 * Created by tom on 2018/3/18.
 */

public class Singleton02 {

        //定义静态属性
        private static Singleton02 instance = null;

        //构造方法私有化

        private Singleton02(){

        }

        //提供暴露外部调用类方法
        public static  Singleton02 getInstance(){
            //在java中称之为双重检查
            if(instance == null){
                //线程安全

                synchronized (Singleton02.class){

                    if(instance == null){
                        instance = new Singleton02();
                    }
                }
            }
            return instance;
        }
}