package tom.lk_architect_singleton_java.simple01;

/**
 * Created by tom on 2018/3/18.
 */

//标准单例(非线程安全)
public class Singleton01 {

    //定义静态属性
    private static Singleton01 instance;

    //构造方法私有化

    private Singleton01(){

    }

    //提供暴露外部调用类方法
    public static  Singleton01 getInstance(){
        if(instance == null){
            instance = new Singleton01();
        }
        return instance;
    }

}
