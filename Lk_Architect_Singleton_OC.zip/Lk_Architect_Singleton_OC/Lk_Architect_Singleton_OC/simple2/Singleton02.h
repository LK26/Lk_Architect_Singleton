//
//  Singleton02.h
//  Lk_Architect_Singleton_OC
//
//  Created by Tom on 2018/3/18.
//  Copyright © 2018年 Tom. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Singleton02 : NSObject

//约束二: 提供一个函数创建单例,如果单例存在就返回,如果不存在就创建
+(instancetype)sharedInstance;

@end
