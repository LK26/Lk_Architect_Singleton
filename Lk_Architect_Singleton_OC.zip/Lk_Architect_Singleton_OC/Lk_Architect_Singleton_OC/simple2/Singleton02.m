//
//  Singleton02.m
//  Lk_Architect_Singleton_OC
//
//  Created by Tom on 2018/3/18.
//  Copyright © 2018年 Tom. All rights reserved.
//

#import "Singleton02.h"

@implementation Singleton02

//约束一: 提供一个静态实例,一般情况下设置为nil.
static Singleton02 * instance = nil;

+(instancetype)sharedInstance{
    
    static  dispatch_once_t once;
    dispatch_once(&once, ^{
        instance = [[Singleton02 alloc]init];
    });
    return instance;
    
}
//当我们调用alloc的时候回调该方法
+(id)allocWithZone:(struct _NSZone *)zone{
    
    if(instance == nil){
        static  dispatch_once_t once;
        dispatch_once(&once, ^{
            instance = [super allocWithZone:zone];
        });
    }
    return instance;
}

@end






