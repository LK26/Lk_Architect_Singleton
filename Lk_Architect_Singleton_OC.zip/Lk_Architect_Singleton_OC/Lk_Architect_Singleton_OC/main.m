//
//  main.m
//  Lk_Architect_Singleton_OC
//
//  Created by Tom on 2018/3/18.
//  Copyright © 2018年 Tom. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Singleton01.h"
#import "Singleton02.h"
#import "Singleton03.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        //一
        //Singleton01 * singleton01 = [[Singleton01 alloc]init];
        //二,GCD
        //Singleton02 *singleton02 = [[Singleton02 alloc]init];
        //三
        
        
        
    }
    return 0;
}
