//
//  Singleton03.m
//  Lk_Architect_Singleton_OC
//
//  Created by Tom on 2018/3/18.
//  Copyright © 2018年 Tom. All rights reserved.
//

#import "Singleton03.h"

@implementation Singleton03

//约束一: 提供一个静态实例,一般情况下设置为nil.
static Singleton03 * instance = nil;

//当我们应用程序运行的时候回调
+(void)load{
    //实例化单例对象
    [Singleton03 sharedInstance];
}
+(instancetype)sharedInstance{
    static  dispatch_once_t once;
    dispatch_once(&once, ^{
        instance = [[Singleton03 alloc]init];
    });
    return instance;
}
//当我们调用alloc的时候回调该方法
+(id)allocWithZone:(struct _NSZone *)zone{
    if(instance == nil){
        static  dispatch_once_t once;
        dispatch_once(&once, ^{
            instance = [super allocWithZone:zone];
        });
    }
    return instance;
}
@end
