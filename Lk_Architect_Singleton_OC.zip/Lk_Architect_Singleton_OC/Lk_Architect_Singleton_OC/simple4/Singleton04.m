//
//  Singleton04.m
//  Lk_Architect_Singleton_OC
//
//  Created by Tom on 2018/3/18.
//  Copyright © 2018年 Tom. All rights reserved.
//

#import "Singleton04.h"

@implementation Singleton04

static Singleton04 *instance = nil;

+(instancetype)sharedInstance{
    //线程安全
    @synchronized(self){
        if(instance == nil){
            instance = [[Singleton04 alloc]init];
        }
    }
    return instance;
}
//当我们调用alloc的时候回调该方法
+(id)allocWithZone:(struct _NSZone *)zone{
    if(instance == nil){
        @synchronized(self){
            instance = [super allocWithZone:zone];
        };
    }
    return instance;
}
@end
