//
//  Singleton01.m
//  Lk_Architect_Singleton_OC
//
//  Created by Tom on 2018/3/18.
//  Copyright © 2018年 Tom. All rights reserved.
//

#import "Singleton01.h"

@implementation Singleton01

//约束一: 提供一个静态实例,一般情况下设置为nil.
static Singleton01 * instance = nil;

+(instancetype)sharedInstance{
    if(instance == nil){
        instance = [[Singleton01 alloc]init];
    }
    return instance;
}
//当我们调用alloc的时候回调该方法
+(id)allocWithZone:(struct _NSZone *)zone{
    if (instance == nil) {
        instance = [super allocWithZone:zone];
    }
    return instance;
}




@end
