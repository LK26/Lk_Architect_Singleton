//
//  Test.swift
//  Lk_Architect_Singleton_Swift
//
//  Created by Tom on 2018/3/18.
//  Copyright © 2018年 Tom. All rights reserved.
//

import Foundation

//class Test: Singleton01 {
//    
//}

