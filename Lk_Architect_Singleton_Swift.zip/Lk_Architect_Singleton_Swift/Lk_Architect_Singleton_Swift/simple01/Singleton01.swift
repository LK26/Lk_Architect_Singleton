//
//  Singleton01.swift
//  Lk_Architect_Singleton_Swift
//
//  Created by Tom on 2018/3/18.
//  Copyright © 2018年 Tom. All rights reserved.
//

import Foundation

//设置不能够继承
final class Singleton01:NSObject{
    
    //默认值为nil
    private static var instance:Singleton01? = nil
    
    //向外提供方法
    class func sharedInstance() -> Singleton01{
        
        if(instance == nil){
            instance = Singleton01();
        }
        return instance!;
    }
    //将构造方法私有化
    private override init() {
        
    }

}
