//
//  Singleton02.swift
//  Lk_Architect_Singleton_Swift
//
//  Created by Tom on 2018/3/18.
//  Copyright © 2018年 Tom. All rights reserved.
//

import Foundation

//声明为finnal类,不允许继承
class Singleton02: NSObject {
    
    private static let instance = Singleton02()
    
    //构造方法私有化
    private override init() {
        
    }
    
    //提供一个方法给外部调用
    
    class func sharedInstance()->Singleton02{
        return instance
    }
}
