//
//  Singleton03.swift
//  Lk_Architect_Singleton_Swift
//
//  Created by Tom on 2018/3/18.
//  Copyright © 2018年 Tom. All rights reserved.
//

import Foundation

class Singleton03: NSObject {
    
    //结构体私有化
   private struct Static {
        static let instance = Singleton03()
    }
    
    //定义一个属性
    class var shared : Singleton03{
        return Static.instance
    }
    //构造方法私有化
    private override init() {
        
    }
    
    
}
